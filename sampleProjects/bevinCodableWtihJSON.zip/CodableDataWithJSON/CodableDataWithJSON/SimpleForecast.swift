//
//  SimpleForecast.swift
//  CodableDataWithJSON
//
//  Created by Bevin Tang on 5/6/18.
//  Copyright © 2018 R. All rights reserved.
//

import Foundation

struct SimpleForecast : Codable {
    var forecastDays : [SimpleForecastDay]
    
    private enum CodingKeys: String, CodingKey {
        case forecastDays = "forecastday"
    }
    
    struct SimpleForecastDay : Codable {
        var date: Date
        var high : High
        var low : Low
        var conditions : String
        var icon_url : String
        var maxwind : MaxWind
        var avewind : AveWind
        
        private enum CodingKeys: String, CodingKey {
            case date = "date"
            case high = "high"
            case low = "low"
            case conditions = "conditions"
            case icon_url = "icon_url"
            case maxwind = "maxwind"
            case avewind = "avewind"
        }
        
        struct Date : Codable {
            var weekday : String
            
            private enum CodingKeys: String, CodingKey {
                case weekday = "weekday"
            }
        }
        
        struct High : Codable {
            var fahrenheit : String
            
            private enum CodingKeys: String, CodingKey {
                case fahrenheit = "fahrenheit"
            }
        }
        
        struct Low : Codable {
            var fahrenheit : String
            
            private enum CodingKeys: String, CodingKey {
                case fahrenheit = "fahrenheit"
            }
        }
        
        struct MaxWind : Codable {
            var mph : Int
            var dir : String
            
            private enum CodingKeys: String, CodingKey {
                case mph = "mph"
                case dir = "dir"
            }
        }
        
        struct AveWind : Codable {
            var mph : Int
            var dir : String
            
            private enum CodingKeys: String, CodingKey {
                case mph = "mph"
                case dir = "dir"
            }
        }
    }
}
