//
//  TrackTouchesVC.swift
//  TouchAndImages
//
//  Created by Randy Scovil on 11/7/16.
//  Copyright © 2016 R. All rights reserved.
//

import UIKit

class TrackTouchesVC: UIViewController {

    @IBOutlet weak var touchState: UILabel!
    
    @IBOutlet weak var xLabel: UILabel!
    
    @IBOutlet weak var yLabel: UILabel!
    
    var touchArray = [CGPoint]()
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        xLabel.text = "Nothing"
        yLabel.text = "Nothing"
        touchState.text = "Touch me"
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        touchArray = [CGPoint]()
        
        let touch = touches.first
        let beginPoint = touch?.location(in: self.view)
        xLabel.text = "\(beginPoint!.x)"
        yLabel.text = "\(beginPoint!.y)"
        
        touchState.text = "Touches Began"
        
        touchArray.append(beginPoint!)
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        let nextPoint = touch?.location(in: self.view)
        xLabel.text = "\(nextPoint!.x)"
        yLabel.text = "\(nextPoint!.y)"
        
        touchState.text = "Touches Moved"
        
        touchArray.append(nextPoint!)
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        let endPoint = touch?.location(in: self.view)
        xLabel.text = "\(endPoint!.x)"
        yLabel.text = "\(endPoint!.y)"
        
        touchState.text = "Touches Ended"
        
        touchArray.append(endPoint!)
        
        showResults()
    }
    
    func showResults() {
        performSegue(withIdentifier: "pushResults", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "pushResults" {
            let destVC = segue.destination as? TouchResultsTVC
            destVC?.results = touchArray        }
    }
    
}
