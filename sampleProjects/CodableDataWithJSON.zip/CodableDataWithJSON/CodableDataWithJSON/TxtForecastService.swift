//
//  TxtForecastService.swift
//  CodableDataWithJSON
//
//  Created by R on 10/15/17.
//  Copyright © 2017 R. All rights reserved.
//

import Foundation

struct TxtForecastService : Codable {
    let forecast : Forecast
    
    struct Forecast: Codable {
        let txt_forecast : TxtForecast
    }
    
}
