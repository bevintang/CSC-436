//
//  ForecastTableViewCell.swift
//  CodableDataWithJSON
//
//  Created by Bevin Tang on 5/6/18.
//  Copyright © 2018 R. All rights reserved.
//

import UIKit

class ForecastTableViewCell: UITableViewCell {
    // Labels
    @IBOutlet weak var weekdayLabel: UILabel!
    @IBOutlet weak var conditionsLabel: UILabel!
    @IBOutlet weak var lowLabel: UILabel!
    @IBOutlet weak var highLabel: UILabel!
    @IBOutlet weak var aveLabel: UILabel!
    @IBOutlet weak var maxLabel: UILabel!
    @IBOutlet weak var dirLabel: UILabel!
    
    
}
