//
//  ViewController.swift
//  CommonProtocols
//
//  Created by R on 11/14/16.
//  Copyright © 2016 R. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // quick examples
        let joe = CSSEStudent(first: "Joe", last: "Blow", major: "CSC")
        let stu = CSSEStudent(first: "Stu", last: "Dent", major: "SE")
        
        let joeClone = joe.copy() as! CSSEStudent
        let joeRefCopy = joe
        
        // Check identical references
        print("joe and joeRefCopy are the same instance: \(joe === joeRefCopy)")
        print("joe and joeClone are the same instance: \(joe === joeClone)")
        
        // Equatable
        print("joe and JoeClone are different, equal instances: \(joe == joeClone)")
        
        // Comparable
        print("joe is less than stu, but only in a Comparable way: \(joe < stu)")
        
        // Hashable, CustomStringConvertible
        let studentSet : Set = [joe, stu, joeClone]
        if studentSet.contains(joe) {
            print("joe is in the set: \(joe)")
        }
        
    }

 }

