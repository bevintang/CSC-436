//
//  SimpleForecastObject.swift
//  CodableDataWithJSON
//
//  Created by Bevin Tang on 5/7/18.
//  Copyright © 2018 R. All rights reserved.
//

import Foundation

class SimpleForecastObject : NSObject {
    var weekday = String();
    var conditions = String();
    var low = String();
    var high = String();
    var avewind = Int();
    var maxwind = Int();
    var icon_url = String();
    
    init (weekday : String, conditions : String, low : String, high : String, avewind : Int, maxwind : Int, icon_url : String){
        self.weekday = weekday;
        self.conditions = conditions;
        self.low = low;
        self.high = high;
        self.avewind = avewind;
        self.maxwind = maxwind
        self.icon_url = icon_url;
    }
}
