//
//  TouchImageVC.swift
//  TouchAndImages
//
//  Created by R on 11/7/16.
//  Copyright © 2016 R. All rights reserved.
//

import UIKit

class TouchImageVC: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        imageView.image = UIImage(named: "0.JPG")
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        var message = ""
        
        let touch = touches.first
 
        if touch?.view?.tag == 10 {
            message = "touched label"
        }
        else if touch?.view?.tag == 20 {
            message = "touched image"
        }
        else {
            message = "touched elsewhere"
        }
        
        let dialog = UIAlertController(title: "Touch happens", message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: "Ok, got it", style: .cancel, handler: nil)
        dialog.addAction(action)
        
        present(dialog, animated: true, completion: nil)

    }

}
