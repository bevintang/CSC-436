//
//  CSSEStudent.swift
//  CommonProtocols
//
//  Created by R on 11/14/16.
//  Copyright © 2016 R. All rights reserved.
//

import Foundation


class CSSEStudent : NSCopying, Equatable, Hashable, Comparable, CustomStringConvertible {
    
    var first : String
    var last : String
    var major : String
    
    init(first : String, last : String, major : String) {
        
        self.first = first
        self.last = last
        self.major = major
    }
    
    // Any return type required by protocol
    func copy(with zone: NSZone? = nil) -> Any {
        return CSSEStudent(first: first, last: last, major: major)
    }
    
    // Equatable and Hashable
    static func == (lhs : CSSEStudent, rhs: CSSEStudent) -> Bool {
        return lhs.first == rhs.first && lhs.last == rhs.last
    }
    
    // Comparable
    static func < (lhs : CSSEStudent, rhs: CSSEStudent) -> Bool {
        return lhs.last < rhs.last
    }
    
    // Hashable - required (computed) property
    var hashValue: Int {
        return first.hashValue ^ last.hashValue
    }
    
    // CustomStringConvertible - required (computed) property
    var description : String {
        return "\(first) \(last), major: \(major) "
    }
}
