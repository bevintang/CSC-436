//
//  TxtForecast.swift
//  CodableDataWithJSON
//
//  Created by R on 10/15/17.
//  Copyright © 2017 R. All rights reserved.
//

import Foundation

struct TxtForecast : Codable {
    var date: String
    var forecastDays : [ForecastDay]
    
    private enum CodingKeys: String, CodingKey {
        case date
        case forecastDays = "forecastday"
    }
    
    struct ForecastDay : Codable {
        var title : String
        var period : Int
        var forecastText : String
        
        private enum CodingKeys: String, CodingKey {
            case title
            case period
            case forecastText = "fcttext"
        }
    }
}


