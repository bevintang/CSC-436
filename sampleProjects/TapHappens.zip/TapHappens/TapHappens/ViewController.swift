//
//  ViewController.swift
//  TapHappens
//
//  Created by R on 4/11/17.
//  Copyright © 2017 R. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var labelLabel: UILabel!
    
    @IBAction func tapHappened(_ sender: UITapGestureRecognizer) {
        labelLabel.text = "Tap!!!!!"
    }
    
    @IBAction func labelTap(_ sender: UITapGestureRecognizer) {
        labelLabel.text = "Label Tap!"
    }
    
    @IBAction func buttonPress(_ sender: UIButton) {
        labelLabel.text = "Button Pressed"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

}

