//
//  ExampleTVC.swift
//  SImpleTableView
//
//  Created by R on 10/10/16.
//  Copyright © 2016 R. All rights reserved.
//

// UITableViewController subclass that displays all of the taco stands

// When a row is selected, segue to detail view controller and pass name

import UIKit

class ExampleTVC: UITableViewController {

    var ourStands = [TacoStand]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Create some Taco Stands
        ourStands.append(TacoStand(name: "Tacos de Acapulco", city: "SLO", specialty: "Carne Asada"))
        ourStands.append(TacoStand(name: "Taqueria Santa Cruz", city: "SLO", specialty: "Combo Plate"))
        ourStands.append(TacoStand(name: "G Bros. Smokehouse", city: "SLO", specialty: "Happy Hour Tacos"))
    }


    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ourStands.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "customCell", for: indexPath) as? CustomTVCell

        // Configure the cell...
        let thisStand = ourStands[indexPath.row]
        cell?.nameLabel?.text = thisStand.name
        cell?.cityLabel?.text = thisStand.city
        cell?.specialtyLabel.text = thisStand.specialty

        return cell!
    }
    
    /*
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("You selected row: \(indexPath.row)")
    }
    */
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */


    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
        if segue.identifier == "showSelectedStand" {
            let destVC = segue.destination as? ViewController
            let selectedIndexPath = tableView.indexPathForSelectedRow
            destVC?.dataFromTable = ourStands[(selectedIndexPath?.row)!].name
        }
        
    }
    
    @IBAction func unwindFromDetail(segue:UIStoryboardSegue) {
    
    }


}
