//
//  TacoStand.swift
//  FIrebaseBasic
//
//  Created by R on 10/30/16.
//  Copyright © 2016 R. All rights reserved.
//

import Foundation
import FirebaseDatabase

class TacoStand {
    
    var name: String
    var city: String
    var specialty: String
    let ref: DatabaseReference?
    
    init(name: String, city: String, specialty: String) {
        self.name = name
        self.city = city
        self.specialty = specialty
        ref = nil
    }
    
    init(snapshot: DataSnapshot) {
        name = snapshot.key
        let snapvalues = snapshot.value as! [String : AnyObject]
        print("snapvalues: \(snapvalues)")
        city = snapvalues["city"] as! String
        specialty = snapvalues["specialty"] as! String //?? "N/A"
        ref = snapshot.ref
    }
    
    func toAnyObject() -> Any {
        return [
            "name" : name,
            "city" : city,
            "specialty" : specialty
        ]
    }
}
