//
//  ViewController.swift
//  SImpleTableView
//
//  Created by R on 10/10/16.
//  Copyright © 2016 R. All rights reserved.
//

// Detail View Controller that displays selected data based on row

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var passedDataLabel: UILabel!
    
    var dataFromTable : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        passedDataLabel.text = dataFromTable
    }

}

