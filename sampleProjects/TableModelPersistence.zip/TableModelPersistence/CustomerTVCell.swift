//
//  CustomerTVCell.swift
//  TableModelPersistence
//
//  Created by Randy Scovil on 3/19/15.
//  Copyright (c) 2015 Randy Scovil. All rights reserved.
//

import UIKit

class CustomerTVCell: UITableViewCell {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var nationLabel: UILabel!
    @IBOutlet weak var repLabel: UILabel!
    
}
