//
//  ViewController.swift
//  DownloadImage-Swift
//
//  Created by R on 6/27/17.
//  Copyright © 2017 R. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    
    
    @IBAction func startDownload(_ sender: AnyObject) {
        
        DispatchQueue.global(qos: .userInitiated).async {
            
            let url = URL(string: "https://pbs.twimg.com/profile_images/659411712144097280/thAyH7J__400x400.jpg")
            let responseData = try? Data(contentsOf: url!)
            let downloadedImage = UIImage(data: responseData!)
            
            DispatchQueue.main.async {
                self.imageView.image = downloadedImage
            }
            
        }
    }
    
}


