//
//  ViewController.swift
//  Map-PinDrop
//
//  Created by R on 10/22/17.
//  Copyright © 2017 R. All rights reserved.
//

import UIKit
import CoreLocation

// Make sure this framework has been added - see General in project settings
import MapKit
// Be sure to enable Maps under Capabilities


class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
    
    @IBOutlet weak var mapView: MKMapView!
    
    static let kSelectedZoom = 0.01
    
    let locationManager = CLLocationManager()
    let reverseGeocoder = CLGeocoder()
    
    let cscBuilding = CLLocationCoordinate2D(latitude: 35.300066, longitude: -120.662065)

    override func viewDidLoad() {
        super.viewDidLoad()
        centerMap(at: cscBuilding)
    }

    func centerMap(at newCenter: CLLocationCoordinate2D, withZoom zoom: Double = 0.1) {
        
        let span = MKCoordinateSpan(latitudeDelta: zoom, longitudeDelta: zoom)
        let newRegion = MKCoordinateRegion(center: newCenter, span: span)
        mapView.setRegion(newRegion, animated: true)
    }
    
    // Action method for gesture recognizer
    @IBAction func longPressOnMap(_ sender: UILongPressGestureRecognizer) {
        // respond to event just once
        if sender.state != .began {
            return
        }
        
        let touchPoint = sender.location(in: mapView)
        let touchMapCoordinate = mapView.convert(touchPoint, toCoordinateFrom: mapView)
        let touchLocation = CLLocation(latitude: touchMapCoordinate.latitude, longitude: touchMapCoordinate.longitude)
        
        var locationName = ""
        var locality = ""
        
        reverseGeocoder.reverseGeocodeLocation(touchLocation, completionHandler:
        { (placemarks, error) in
            if error == nil {
                if let firstLocation = placemarks?[0] {
                    locationName = firstLocation.name!
                    locality = firstLocation.locality!
                    
                    let foodDestination = Locale(coord: touchMapCoordinate,named:locationName,detail:locality)
                    self.mapView.addAnnotation(foodDestination)
                    
                    self.centerMap(at: touchMapCoordinate, withZoom: ViewController.kSelectedZoom
                    )
                }
            }
            else {
                print(error!)
            }
        })
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let pinView = MKPinAnnotationView()
        pinView.pinTintColor = .red
        pinView.canShowCallout = true
        
        // add callout disclosure button
        let disclosureButton = UIButton(type: .detailDisclosure)
        pinView.rightCalloutAccessoryView = disclosureButton
    
        return pinView
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        performSegue(withIdentifier: "pushResultsTable", sender: view.annotation!)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // add conditional
        if segue.identifier == "pushResultsTable" {
            if let selectedLocale = sender as? Locale {
                let destVC = segue.destination as! TableViewController
                destVC.locale = selectedLocale
                destVC.mapRegion = mapView.region
            }
        }
    }
    
}

