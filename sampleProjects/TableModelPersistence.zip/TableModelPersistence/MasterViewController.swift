//
//  MasterViewController.swift
//  TableModelStarter
//
//  Created by Randy Scovil on 2/26/15.
//  Copyright (c) 2015 Randy Scovil. All rights reserved.
//

import UIKit


class MasterViewController: UITableViewController {
    
    static let documentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    
    static let archiveURL = documentsDirectory.appendingPathComponent("savedCustomers")


    var customers : [Customer] = []
    var ourDefaults = UserDefaults.standard
    
    var dateFormatter = DateFormatter()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .medium
        
        // Do any additional setup after loading the view, typically from a nib.
        self.navigationItem.leftBarButtonItem = self.editButtonItem

        let addButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(insertNewObject(_:)))
        self.navigationItem.rightBarButtonItem = addButton
        
        // init with persisted data, if any
        if let lastUpdate = ourDefaults.object(forKey: "lastUpdate") as? Date {
            
            let updateString = dateFormatter.string(from: lastUpdate)
            let dialogString = "Data was last updated:\n\(updateString)"
            
            let dialog = UIAlertController(title: "Data Restored", message: dialogString, preferredStyle: .alert)
            
            let action = UIAlertAction(title: "Go Away", style: .cancel, handler: nil)
            dialog.addAction(action)
            
            present(dialog, animated: true, completion: nil)
            
            if let tempArr = NSKeyedUnarchiver.unarchiveObject(withFile: MasterViewController.archiveURL.path) as? [Customer] {
                customers = tempArr
            }
        }
    }

    @objc func insertNewObject(_ sender: AnyObject) {
        let custNum = customers.count + 1

        customers.append(Customer(name: String(custNum), country: String(custNum * 10), rep: String(custNum * 100)))

        self.tableView.reloadData()
        
        updatePersistentStorage()
    }
    
    func updatePersistentStorage() {
        // persist data
        NSKeyedArchiver.archiveRootObject(customers, toFile: MasterViewController.archiveURL.path)
        
        // timestamp last update
        ourDefaults.set(Date(), forKey: "lastUpdate")
    }

    // MARK: - Segues

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetail" {
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let object = customers[(indexPath as NSIndexPath).row]
            (segue.destination as! DetailViewController).detailItem = object
            }
        }
    }

    // MARK: - Table View

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return customers.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CustomerCell", for: indexPath) as! CustomerTVCell

        let object = customers[(indexPath as NSIndexPath).row]
        cell.nameLabel.text = object.name
        cell.nationLabel.text = object.country
        cell.repLabel.text = object.salesRep

        return cell
    }

    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }

    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            customers.remove(at: (indexPath as NSIndexPath).row)
            tableView.deleteRows(at: [indexPath], with: .fade)
            updatePersistentStorage()
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
        }
    }

}

