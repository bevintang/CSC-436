//
//  Customer.swift
//  TableModelStarter
//
//  Created by Randy Scovil on 2/26/15.
//  Copyright (c) 2015 Randy Scovil. All rights reserved.
//

import Foundation

// NSObject superclass required
class Customer : NSObject, NSCoding {
    
    var name : String
    var country : String
    var salesRep : String
    
    init (name: String, country: String, rep: String) {
        
        self.name = name
        self.country = country
        salesRep = rep
    }
        
    required init?(coder aDecoder: NSCoder) {
        name = aDecoder.decodeObject(forKey: "name") as! String
        country = aDecoder.decodeObject(forKey: "country") as! String
        salesRep = aDecoder.decodeObject(forKey: "salesRep") as! String
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(name, forKey: "name")
        aCoder.encode(country, forKey: "country")
        aCoder.encode(salesRep, forKey: "salesRep")
    }
    
    override var description : String {
        get {
            return "Name: \(name)  Country: \(country)  Rep: \(salesRep)"
        }
    }
}
