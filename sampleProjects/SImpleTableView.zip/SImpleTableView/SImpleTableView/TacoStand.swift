//
//  TacoStand.swift
//  SImpleTableView
//
//  Created by R on 7/5/17.
//  Copyright © 2017 R. All rights reserved.
//


import Foundation

class TacoStand {
    
    var name: String
    var city: String
    var specialty: String
    
    init(name: String, city: String, specialty: String) {
        self.name = name
        self.city = city
        self.specialty = specialty
    }
}
