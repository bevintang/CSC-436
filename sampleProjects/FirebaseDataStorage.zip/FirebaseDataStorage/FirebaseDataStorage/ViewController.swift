//
//  ViewController.swift
//  FirebaseDataStorage
//
//  Created by R on 3/4/18.
//  Copyright © 2018 R. All rights reserved.
//

import UIKit
import Photos
import Firebase


class ViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var titleTF: UITextField!
    @IBOutlet weak var photoIV: UIImageView!
    
    var databaseRef : DatabaseReference!
    var imagesRef  :  StorageReference!
    
    
    // MARK: - UIViewController Lifecycle methods
    
    override func viewDidLoad() {
        super.viewDidLoad()
        databaseRef = Database.database().reference().child("photoInfo")
        imagesRef = Storage.storage().reference().child("images")
     }
    
    
    // MARK: - UITextFieldDelegate methods
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    
    // MARK: - UIImagePickerControllerDelegate methods
    
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [String : Any]) {
        
        guard let image = info[UIImagePickerControllerOriginalImage] as? UIImage else { return }
        
        photoIV.image = image
        
        picker.dismiss(animated: true, completion:nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion:nil)
    }
    
   
    // MARK: - IBAction methods
    
    @IBAction func takePhoto(_ sender: UIButton) {
        
        let picker = UIImagePickerController()
        picker.delegate = self
        // default to photo library if camera unavailable
        picker.sourceType = UIImagePickerController.isSourceTypeAvailable(.camera) ? .camera : .photoLibrary
        
        present(picker, animated: true, completion:nil)
    }
    
    @IBAction func uploadToFirebase(_ sender: Any) {
        
        guard titleTF.text != "", photoIV.image != nil else {
            return
        }
        
        let photoInfo = PhotoInfo(title: titleTF.text!)
        
        let newPhotoInfoRef = databaseRef.child(titleTF.text!)
        newPhotoInfoRef.setValue(photoInfo.toAny())
        
        let imageData = UIImageJPEGRepresentation(photoIV.image!, 1.0)
        let metadata = StorageMetadata()
        metadata.contentType = "image/jpeg"
        let imagePath = titleTF.text! + ".jpeg"
        print(imagePath)
 
        self.imagesRef.child(imagePath).putData(imageData!, metadata: metadata) { (metadata, error) in
 
            if let error = error {
                print("Error uploading: \(error) for image: \(imagePath)")
            }
            else {
                if let url = metadata?.downloadURL()?.absoluteString{
                    print("Image uploaded at \(url)")
                    // version without callback - can use either one
//                    newPhotoInfoRef.updateChildValues(["photoKey" : url])
                    newPhotoInfoRef.updateChildValues(["photoKey" : url])
                    { error, databaseRef in
                        if let error = error {
                            print("Error updating image URL: \(error)")
                        }
                        else {
                            print("Image URL successfully updated.")
                        }
                    }
                }
            }
        }
    }
}

