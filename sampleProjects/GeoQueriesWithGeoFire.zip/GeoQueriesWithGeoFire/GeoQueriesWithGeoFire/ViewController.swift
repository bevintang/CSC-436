//
//  ViewController.swift
//  GeoQueriesWithGeoFire
//
//  Created by R on 2/8/18.
//  Copyright © 2018 R. All rights reserved.
//

import UIKit
import MapKit
import Firebase
import GeoFire
import CoreLocation


class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {

    @IBOutlet weak var mapView: MKMapView!
    
    var databaseRef : DatabaseReference?
    var geoFire : GeoFire?
    var regionQuery : GFRegionQuery?
    let locationManager = CLLocationManager()
    let cscBuilding = CLLocationCoordinate2D(latitude: 35.300066, longitude: -120.662065)
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureLocationManager()
        
        databaseRef = Database.database().reference().child("TacoStands")
        geoFire = GeoFire(firebaseRef: Database.database().reference().child("GeoFire"))
        
        let span = MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        let newRegion = MKCoordinateRegion(center: cscBuilding, span: span)
        mapView.setRegion(newRegion, animated: true)
        
        //oneTimeInit()
    }
    
    func configureLocationManager() {
        CLLocationManager.locationServicesEnabled()
        locationManager.requestWhenInUseAuthorization()
        locationManager.delegate = self
        locationManager.desiredAccuracy = 1.0
        locationManager.distanceFilter = 100.0
        locationManager.startUpdatingLocation()
    }

//    func oneTimeInit() {
//        databaseRef?.queryOrdered(byChild: "TacoStands").observe(.value, with:
//            { snapshot in
//
//                var newStands = [TacoStand]()
//
//                for item in snapshot.children {
//                    newStands.append(TacoStand(snapshot: item as! DataSnapshot))
//                }
//
//                for next in newStands {
//                    self.geoFire?.setLocation(CLLocation(latitude:next.latitude,longitude:next.longitude), forKey: next.name)
//                }
//        })
//    }
//
    
    func mapView(_ mapView: MKMapView, regionDidChangeAnimated animated: Bool) {
        mapView.removeAnnotations(mapView.annotations)
        
        updateRegionQuery()
    }

    func updateRegionQuery() {
        if let oldQuery = regionQuery {
            oldQuery.removeAllObservers()
        }
        
        regionQuery = geoFire?.query(with: mapView.region)
        
        regionQuery?.observe(.keyEntered, with: { (key, location) in
             self.databaseRef?.queryOrderedByKey().queryEqual(toValue: key).observe(.value, with: { snapshot in
                
                let newStand = TacoStand(key:key,snapshot:snapshot)
                self.addStand(newStand)
            })
         })
    }
    
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        mapView.setRegion(MKCoordinateRegionMake((mapView.userLocation.location?.coordinate)!, MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)), animated: true)
        
    }
    
    func addStand(_ stand : TacoStand) {
        DispatchQueue.main.async {
            self.mapView.addAnnotation(stand)
        }
    }
   
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {

        if annotation is TacoStand {
            let annotationView = MKPinAnnotationView()
            annotationView.pinTintColor = .red
            annotationView.annotation = annotation
            annotationView.canShowCallout = true
            annotationView.animatesDrop = true

            return annotationView
        }

        return nil
    }
}

