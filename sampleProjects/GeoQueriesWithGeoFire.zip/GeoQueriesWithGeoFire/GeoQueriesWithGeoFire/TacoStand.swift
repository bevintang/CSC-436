//
//  TacoStand.swift
//  FIrebaseBasic
//
//  Created by R on 10/30/16.
//  Copyright © 2016 R. All rights reserved.
//

import Foundation
import FirebaseDatabase
import MapKit

class TacoStand : NSObject, MKAnnotation {
    
    var name: String
    var city: String
    var specialty: String
    let ref: DatabaseReference?
    var latitude : Double
    var longitude : Double
    
    var coordinate: CLLocationCoordinate2D {
        return CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }
    
    var title: String? {
        return name
    }
    
    var subtitle: String? {
        return city
    }
    
    init(name: String, city: String, specialty: String) {
        self.name = name
        self.city = city
        self.specialty = specialty
        self.latitude = 0
        self.longitude = 0
        ref = nil
        
        super.init()
    }
    
    init(key: String,snapshot: DataSnapshot) {
        name = key
        
        let snaptemp = snapshot.value as! [String : AnyObject]
        let snapvalues = snaptemp[key] as! [String : AnyObject]
        
        city = snapvalues["city"] as? String ?? "N/A"
        specialty = snapvalues["specialty"] as? String ?? "N/A"
        latitude = snapvalues["latitude"] as? Double ?? 0.0
        longitude = snapvalues["longitude"] as? Double ?? 0.0
        
        ref = snapshot.ref
        
        super.init()
    }
    
    func toAnyObject() -> Any {
        return [
            "name" : name,
            "city" : city,
            "specialty" : specialty,
            "latitude" : latitude,
            "longitude" : longitude
        ]
    }
}
