//
//  TableViewController.swift
//  CodableDataWithJSON
//
//  Created by R on 10/15/17.
//  Copyright © 2017 R. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {

    let apiString3DayForecast = "https://api.wunderground.com/api/7985bb042e49e505/forecast10day/q/CA/Pismo_Beach.json"
    
    var simpleForecast : SimpleForecast?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let session = URLSession(configuration: URLSessionConfiguration.default)
        
        let request = URLRequest(url: URL(string: apiString3DayForecast)!)
        
        let task: URLSessionDataTask = session.dataTask(with: request)
        { (receivedData, response, error) -> Void in
            
            if let data = receivedData {
                do {
                    let decoder = JSONDecoder()
                    let simpleForecastService = try decoder.decode(SimpleForecastService.self, from: data)
                    
                    self.simpleForecast = simpleForecastService.forecast.simpleforecast
                    
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                    
                } catch {
                    print("Exception on Decode: \(error)")
                }
            }
        }
        task.resume()
                
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (simpleForecast?.forecastDays.count) ?? 0
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "forecastCell", for: indexPath) as? ForecastTableViewCell

        let forecastDay = simpleForecast!.forecastDays[indexPath.row]
        
        // Configure the cell...
        cell?.weekdayLabel.text = "\(forecastDay.date.weekday)"
        cell?.conditionsLabel.text = "\(forecastDay.conditions)"
        cell?.lowLabel.text = "\(forecastDay.low.fahrenheit)"
        cell?.highLabel.text = "\(forecastDay.high.fahrenheit)"
        cell?.aveLabel.text = "\(forecastDay.avewind.mph)"
        cell?.maxLabel.text = "\(forecastDay.maxwind.mph)"
        cell?.dirLabel.text = "\(forecastDay.avewind.dir)"

        return cell!
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
