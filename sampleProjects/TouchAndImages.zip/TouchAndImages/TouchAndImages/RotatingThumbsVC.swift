//
//  RotatingThumbsVC.swift
//  TouchAndImages
//
//  Created by R on 11/7/16.
//  Copyright © 2016 R. All rights reserved.
//

import UIKit

class RotatingThumbsVC: UIViewController {

    @IBOutlet weak var thumbImageView: UIImageView!
    
    var images = [UIImage]()
    
    let kNUMIMAGES = 32
    let kANIMATION_DURATION = 1.0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        loadImages()
        loadImageView()
    }

    func loadImages() {
        for i in 0..<kNUMIMAGES {
            
            let temp = UIImage(named: "\(i).JPG")!

            let imageRect = CGRect(origin: CGPoint(x: 0, y: 0), size: CGSize(width: 50, height: 50))

            UIGraphicsBeginImageContext(imageRect.size)
            temp.draw(in: imageRect)
            let thumbnail = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            
            images.append(thumbnail!)
        }
    }
    
    func loadImageView() {
        thumbImageView.animationImages = images
        thumbImageView.animationDuration = kANIMATION_DURATION * Double(images.count)
        thumbImageView.startAnimating()
    }
}
