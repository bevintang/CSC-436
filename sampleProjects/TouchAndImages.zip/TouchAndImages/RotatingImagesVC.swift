//
//  RotatingImagesVC.swift
//  TouchAndImages
//
//  Created by R on 11/7/16.
//  Copyright © 2016 R. All rights reserved.
//

import UIKit

class RotatingImagesVC: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    
    var images = [UIImage]()
    
    let kNUMIMAGES = 32
    let kANIMATION_DURATION = 1.0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        loadImages()
        loadImageView()
    }
    
    func loadImages() {
        for i in 0..<kNUMIMAGES {
            images.append(UIImage(named: "\(i).JPG")!)
        }
    }
    
    func loadImageView() {
        imageView.animationImages = images
        imageView.animationDuration = kANIMATION_DURATION * Double(images.count)
        imageView.startAnimating()
    }

}
