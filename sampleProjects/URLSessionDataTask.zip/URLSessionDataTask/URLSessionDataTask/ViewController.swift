//
//  ViewController.swift
//  URLSessionDataTask
//
//  Created by R on 10/25/16.
//  Copyright © 2016 R. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    // URLs with API key embedded
    let apiString3DayForecast = "https://api.wunderground.com/api/06210f961278c558/forecast/q/CA/San_Francisco.json"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let session = URLSession(configuration: URLSessionConfiguration.default)
        
        let request = URLRequest(url: URL(string: apiString3DayForecast)!)
        
        let task: URLSessionDataTask = session.dataTask(with: request)
        { (receivedData, response, error) -> Void in
            
            if let data = receivedData {
                
                // uncomment to print raw response
//                let rawDataString = String(data: data, encoding: String.Encoding.utf8)
//                print(rawDataString!)

                var jsonResponse : [String:AnyObject]?
                
                do {
                    jsonResponse = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.allowFragments) as? [String:AnyObject]
                    print("jsonResponse type: \(type(of: jsonResponse))")
                }
                catch {
                    print("Caught exception")
                }
                
                // print dictionary after serialization
//                print(jsonResponse!)
                
                // check high-level keys for collections
                print()
                for (key,value) in jsonResponse! {
                    if value is [String:AnyObject] {
                        print("\(key) is a Dictionary")
                    }
                    else if value is [AnyObject] {
                        print("\(key) is an Array")
                    }
                    else {
                        print(type(of: value))
                    }
                }
                //}
                
                print("\nDrill down of JSON structure:")
                self.jsonDrillDown(json: jsonResponse!, indent: "")
            }
        }
        
        task.resume()
    }
    
    func jsonDrillDown(json : Any, indent: String) {
        let ourIndent = indent + "\t"
        
        if json is Dictionary<String,Any> {
            let dict = json as! Dictionary<String,Any>
            for (key, value) in dict {
                if value is Dictionary<String, Any> {
                    print("\(ourIndent)\(key) is a dictionary ->")
                    jsonDrillDown(json: value, indent: ourIndent)
                } else if value is Array<Any> {
                    let array = value as! Array<Any>
                    let first = array.first
                    if first is Dictionary<String,Any> {
                        print("\(ourIndent)\(key) array -> type is a dictionary ->")
                        jsonDrillDown(json: first!, indent: ourIndent)
                    }
                } else {
                    //print("\(ourIndent)\(key) : \(type (of: value))")
                    print("\(ourIndent)\(key) : " + convertToSwiftName(value: value))
                }
            }
        } else if json is Array<Any> {
            let array = json as! Array<Any>
            let first = array.first
            if first is Dictionary<String,Any> {
                print("\(ourIndent)array -> type is a dictionary ->")
                jsonDrillDown(json: first!, indent: ourIndent)
            }
        }
        else {
            //print("\(ourIndent)type: \(type (of: json))")
            print("\(ourIndent)type: " + convertToSwiftName(value: json))
        }
    }
    
    func convertToSwiftName(value : Any) -> String {
        switch value {
        case is NSString:
            return "String"
        case is NSNumber:
            return "Number"
        case is NSNull:
            return "Null"
        default:
            return "****** something else! \(type(of: value))"
        }
    }
}

