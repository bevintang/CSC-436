//
//  ViewController.swift
//  BackgroundLocation
//
//  Created by R on 2/6/18.
//  Copyright © 2018 R. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {

    @IBOutlet weak var mapView: MKMapView!
    
    let locationManager = CLLocationManager()
    
    var annotations = [MKPointAnnotation]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
 
        initLocationManager()
    }
        
    func initLocationManager() {
        locationManager.requestAlwaysAuthorization()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = 100.0
        locationManager.startUpdatingLocation()
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        print("didUpdate")
        let mostRecent = locations.last!
        
        let newAnnotation = MKPointAnnotation()
        newAnnotation.coordinate = mostRecent.coordinate
        
        annotations.append(newAnnotation)
        
        if UIApplication.shared.applicationState == .active {
            mapView.showAnnotations(annotations, animated: true)
        }
    }

}

