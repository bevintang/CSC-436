//
//  CustomTVCell.swift
//  SImpleTableView
//
//  Created by R on 10/10/16.
//  Copyright © 2016 R. All rights reserved.
//

import UIKit

class CustomTVCell: UITableViewCell {
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var specialtyLabel: UILabel!
    
}
