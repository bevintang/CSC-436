//
//  TableViewController.swift
//  CodableDataWithJSON
//
//  Created by R on 10/15/17.
//  Copyright © 2017 R. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {

    let apiString3DayForecast = "https://api.wunderground.com/api/06210f961278c558/forecast/q/CA/San_Luis_Obispo.json"
    
    var txtForecast : TxtForecast?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let session = URLSession(configuration: URLSessionConfiguration.default)
        
        let request = URLRequest(url: URL(string: apiString3DayForecast)!)
        
        let task: URLSessionDataTask = session.dataTask(with: request)
        { (receivedData, response, error) -> Void in
            
            if let data = receivedData {
                do {
                    let decoder = JSONDecoder()
                    let txtForecastService = try decoder.decode(TxtForecastService.self, from: data)
                    
                    self.txtForecast = txtForecastService.forecast.txt_forecast
                    
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                    
                } catch {
                    print("Exception on Decode: \(error)")
                }
            }
        }
        task.resume()
                
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (txtForecast?.forecastDays.count) ?? 0
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "forecastDayCell", for: indexPath)

        let forecastDay = txtForecast!.forecastDays[indexPath.row]
        
        // Configure the cell...
        cell.textLabel?.text = "\(String(describing: forecastDay.period))   \(forecastDay.title)"
        cell.detailTextLabel?.text = "\(forecastDay.forecastText)"

        return cell
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
